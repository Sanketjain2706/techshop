create database pranay;
use pranay;
-- Customer table
CREATE TABLE Customer (
    customerId INT PRIMARY KEY,
    name VARCHAR(255),
    emailAddress VARCHAR(255),
    phoneNumber VARCHAR(15),
    address VARCHAR(255),
    creditScore INT
);

-- Loan table
CREATE TABLE Loan (
    loanId INT PRIMARY KEY,
    customerId INT,
    principalAmount DOUBLE,
    interestRate DOUBLE,
    loanTerm INT,
    loanType VARCHAR(50),
    loanStatus VARCHAR(50),
    FOREIGN KEY (customerId) REFERENCES Customer(customerId)
);

-- HomeLoan table
CREATE TABLE HomeLoan (
    loanId INT PRIMARY KEY,
    propertyAddress VARCHAR(255),
    propertyValue INT,
    FOREIGN KEY (loanId) REFERENCES Loan(loanId)
);

-- CarLoan table
CREATE TABLE CarLoan (
    loanId INT PRIMARY KEY,
    carModel VARCHAR(50),
    carValue INT,
    FOREIGN KEY (loanId) REFERENCES Loan(loanId)
);

-- Insert data into Customer table
INSERT INTO Customer (customerId, name, emailAddress, phoneNumber, address, creditScore)
VALUES
    (1, 'John Doe', 'john.doe@email.com', '123-456-7890', '123 Main St', 750),
    (2, 'Jane Smith', 'jane.smith@email.com', '987-654-3210', '456 Oak St', 800),
    (3, 'Alice Johnson', 'alice.johnson@email.com', '555-123-4567', '789 Elm St', 700),
    (4, 'Bob Wilson', 'bob.wilson@email.com', '111-222-3333', '456 Oak St', 720),
    (5, 'Eva Martinez', 'eva.martinez@email.com', '777-888-9999', '321 Birch St', 780);    

-- Insert additional data into Loan table
INSERT INTO Loan (loanId, customerId, principalAmount, interestRate, loanTerm, loanType, loanStatus)
VALUES
    (103, 3, 12000.00, 6.5, 18, 'HomeLoan', 'Pending'),
    (104, 4, 8000.00, 3.8, 36, 'CarLoan', 'Approved'),
    (105, 5, 25000.00, 4.2, 24, 'HomeLoan', 'Pending'),
    (101, 1, 10000.00, 5.0, 12, 'HomeLoan', 'Pending'),
    (102, 2, 15000.00, 4.5, 24, 'CarLoan', 'Approved');
-- Corrected HomeLoan table insert
INSERT INTO HomeLoan (loanId, propertyAddress, propertyValue)
VALUES
    (101, '234 Oak St', 150000),  -- Corresponding to loanId 101 in Loan table
    (105, '890 Cedar St', 300000), -- Corresponding to loanId 105 in Loan table
    (103, '234 Oak St', 150000);

-- Corrected CarLoan table insert
INSERT INTO CarLoan (loanId, carModel, carValue)
VALUES
    (102, 'Ford Mustang', 30000),      -- Corresponding to loanId 102 in Loan table
    (104, 'Chevrolet Malibu', 18000);  -- Corresponding to loanId 104 in Loan table

select * from loan;
select * from customer;

 