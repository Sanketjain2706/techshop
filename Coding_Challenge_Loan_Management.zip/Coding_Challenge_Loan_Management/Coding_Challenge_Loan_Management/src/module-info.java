/**
 * 
 */
/**
 * @author Sanket
 *
 */
module Pranay_CC_LoanManagement {
	requires java.sql;
}